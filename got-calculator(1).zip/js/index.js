var result=[];
    var g;
    var o;
    var t;

    $('.clear').on('click', function () {
        result.splice(0);
        $('#input').empty();

    });

     $('#one').on('click', function () {
         result.push(1);
         $('#input').html(result);
     });

     $('#dos').on('click', function () {
         result.push(2);
         $('#input').html(result);
     });

     $('#tres').on('click', function () {
        result.push(3);
        $('#input').html(result);
    });

     $('#cua').on('click', function () {
        result.push(4);
        $('#input').html(result);
    });

    $('#five').on('click', function () {
         result.push(5);
        $('#input').html(result);
    });

    $('#six').on('click', function () {
        result.push(6);
        $('#input').html(result);
    });

    $('#seven').on('click', function () {
         result.push(7);
        $('#input').html(result);
    });

    $('#acht').on('click', function () {
         result.push(8);
        $('#input').html(result);
    });

    $('#nue').on('click', function () {
         result.push(9);
        $('#input').html(result);
    });

    $('#o').on('click', function () {
         result.push(0);
        $('#input').html(result);
    });

    $('#decimal').on('click', function () {
        result.push('.');
        $('#input').html(result);
    });
    function calculation(){

        result.forEach(function(element,index,array){
       
            if (isNaN(parseInt(element)) && element != "." && index != result.length-1) {

                g = result.splice(0,index).join("");
                o = result.splice(1,result.length-2).join("");

                if (element=="+") {
                    t = parseFloat(g) + parseFloat(o);
                }

                if (element=="-") {
                    t = parseFloat(g) - parseFloat(o);
                }

                if (element=="x") {
                    t = parseFloat(g) * parseFloat(o);
                }

                if (element=="/") {
                    t = parseFloat(g) / parseFloat(o);
                }

                result[0]=t;

                $('#input').html(t);

            }
        });

    }

    function empty(){
            if (parseFloat(t)!= 0 && result.length == 0) {
                result[0] = t;
            }
    }

    $('#plus').on('click', function () {
        empty();
        result.push('+');
        $('#input').html(result);
        calculation();
    });

    $('#minus').on('click', function () {
        empty();
        result.push('-');
        $('#input').html(result);
        calculation();
    });

    $('#divide').on('click', function () {
        empty();
        result.push('/');
        $('#input').html(result);
        calculation();
    });

    $('#X').on('click', function () {
        empty();
        result.push('x');
        $('#input').html(result);
        calculation();
    });

    $('#equal').on('click', function(){

        result.forEach(function(element,index,array){

            if (isNaN(parseInt(element)) && element != ".") {
                g= result.splice(0,index).join("");
                o = result.splice(1).join("");

                if (element=="+") {
                    t = parseFloat(g) + parseFloat(o);
                }

                if (element=="-") {
                    t = parseFloat(g) - parseFloat(o);
                }

                if (element=="x") {
                    t = parseFloat(g) * parseFloat(o);
                }

                if (element=="/") {
                    t = parseFloat(g) / parseFloat(o);
                }

                $('#input').html(t);
                result.splice(0);

            }
           
        });
    });